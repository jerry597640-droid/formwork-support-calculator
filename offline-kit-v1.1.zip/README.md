# 模板支撐互動分析

包含樓板、梁、柱、牆模板檢核，L2 ↔ Y、L3 ↔ X 尺寸連動，以及詳細 Word 計算書匯出。

使用 GitHub Pages 開啟，或下載完整儲存庫後開啟 index.html。所有運算與 Word 函式庫均在本機執行。

計算依提供的原始 VB 程式移植，適用範圍與公式詳見頁面；未宣稱已依現行規範完成校訂。

第三方 docx 函式庫授權詳見 vendor/docx-LICENSE.txt。

詳細過程版本：每次計算由同一引擎留下側壓分段、係數、截面及支柱過程；Word與列印保留同次輸入。新增動態局部受載圖與單檔離線下載，無效或尚未重算的輸入不能匯出。

重建：在本repo執行 `node build.cjs`，以 `template.html` 與本repo來源、圖片及vendor產生自含 `index.html`。解壓離線ZIP後也能獨立重建，不依賴工程入口repo。驗證與原式限制見 `FINAL-VALIDATION.md`。

本機回歸：`node verify.cjs`，用固定來源的 `qa-baseline-engine.js` 比對864案例及獨立基本公式。

import asyncio,certifi,json,subprocess
from pathlib import Path
# Use the host certificate bundle only when supplied by your environment.
import os
if os.environ.get('SSL_CERT_FILE'): certifi.where=lambda:os.environ['SSL_CERT_FILE']
import edge_tts
scenes=[
('選擇分析類型','先選擇樓板、梁、柱或牆。第一次使用，按輸入範例，載入對應案例。範例是教學假設，不能直接當作工地設計值。'),
('填寫載重與材料','依設計圖、澆置計畫和材料資料填寫參數。每個欄位下方都有定義與資料來源。注意，跨距用公尺，斷面尺寸用公分；衝擊載重是加數，不是倍率。'),
('間距雙向連動','以樓板為例，L一是角材間距，L二是貫材間距，L三是支柱間距。將 L三改為零點八公尺，支撐分攤寬 X會同步變為八十公分。L二則與 Y連動。'),
('閱讀檢核結果','切換構件檢核，逐項查看彎曲、剪應力與撓度。紅色 NG代表超限，應查明原因再調整。敏感度只提供獨立試算，不會改動原輸入；也不能只調到顯示 OK就認定安全。'),
('查詢規範與適用範圍','開啟規範檢視，輸入支撐總高度及面積，查看設計責任分類。這裡的高度，不是混凝土澆置高度。逐項確認圖說、澆置、基礎與現場查驗；整架穩定仍需另行設計。'),
('匯出與手機操作','確認輸入及計算過程後，按匯出 Word，保存計算書。手機可使用底部按鈕切換參數與结果。操作影片、參數字典和規範檢視，隨時都能從上方開啟。')]
async def main():
 out=[];start=0
 for i,(title,text) in enumerate(scenes):
  f=Path(__file__).parent/f'audio-{i}.mp3'
  await edge_tts.Communicate(text,'zh-TW-HsiaoChenNeural',rate='-8%').save(str(f))
  duration=float(subprocess.check_output(['ffprobe','-v','quiet','-show_entries','format=duration','-of','csv=p=0',str(f)]))+1.4
  out.append(dict(title=title,text=text,start=round(start,3),duration=round(duration,3)));start+=duration
 Path(__file__).with_name('chapters.json').write_text(json.dumps(out,ensure_ascii=False))
 print('seconds',start)
asyncio.run(main())

# 模板支撐詳細過程 — 本地交接

儲存庫 `jerry597640-droid/formwork-support-calculator`；最新main基線 `856dc1cf9588f6b7da780cf741d02c312e9035b5`。重新讀取18樹項、16檔來源，含固定SHA的4原圖與既有DOCX vendor。未發現AGENTS/.agents/skills、測試或建置指令；依README沿用本機計算與原報告版型。本地完成，未推送。

## 發佈檔案與修改

- `engine.js`：同一次計算的完整輸入快照、側壓實際分段與逐層min/max/密度修正、SCC原分段表及選列、面與線載重傳遞、斷面、內力、應力、撓度候選最小值、鋼管與木柱折減分支、緊結器及嚴格不等式判定。沒有虛構材料查表、取整或建議支數。
- `app.js`：既有原圖、工作視圖、敏感度、尺寸雙向連動、操作範例與說明保留。新增實際引擎明細及動態局部受載/跨距/分攤圖；Word、列印与離線使用同一份結果。
- `word-report.js`：保留原五章與字型表格設定，新增第六章同引擎完整trace、SCC選列表，第七章本次圖。原子快照在所有await前擷取；PNG嵌入真OOXML。
- `style.css`：明細折疊與手機换行；新圖字色經截圖修正，保留原桌機/手機工作区。
- `workbench.js`：僅修正静態獨立驗算範例 EI 筆誤：70,000,000 kgf·cm²才對應 δ=.186012 cm。原7,000,000會得到1.860119；未改任何引擎式。
- `template.html`：保留原入口結構及各來源引用，新增離線下載與輸入還原資料。
- `build.cjs`、`index.html`：所有腳本、CSS、原圖、既有DOCX vendor內嵌成可直接file://開啟的單檔。原help/examples/vendor/image檔保留，可用template重建。
- `build-offline.cjs`、`offline-kit-v1.1.zip`：本輪新增並全新建置，包含可重建来源及原vendor授權。遠端原版沒有ZIP。

## 測試證據

- `validation-results.json`／`verify.cjs`：864案例、81,864原有欄位數值及狀態比較全過。包含四模式、四側壓、H=1.5/2/3/4及R=2.1/10/20附近分段邊界，三支撐、三撓度。獨立矩形與簡支梁、X↔L3及Y↔L2雙向連動亦過。
- `browser-validation.json`／`qa-browser.cjs`：106檢核，Edge file://，1440/768/390/320四寬、四模式與五工作視圖；0外連、0pageerror、頁面無橫向溢出。圖與明細實際截圖 `qa-model-*`、`qa-trace-*`。
- 四模式 `qa-{mode}.docx`及手機 `qa-mobile.docx`：OOXML可解壓，包含原生表格、完整代入與本次PNG圖。
- `branch-validation.json`／`qa-branches.cjs`：7額外報告分支，木柱、指定支架、鋼管彈性、柱/牆SCC、液壓、指定側壓；SCC原生表有實際選列。
- 原子快照捕获H=6.85後异步圖转換期間改H=9，快照仍6.85；未重算輸入與無效跨距禁止Word。敏感度拉霸不改原設計。
- `qa-offline.html`：保留beam模式及全部模式輸入，直接file://重開后計算與Word正常；無外部依賴。
- `offline-validation.json`：ZIP解壓alone後執行本repo `build.cjs`，index逐字匹配；四模式的單檔HTML輸入还原全過，0外連。本repo自帶原vendor、MIT LICENSE與README，沒有hub相對依賴。
- `qa-print.cjs`：列印包含同次完整trace與動態圖，印刷媒體下圖可見；無效跨距禁用離線下載。
- Word排版renderer不可用；確認OOXML/原生表/PNG，不宣稱Word實際分頁已目視。

## 原公式限制（未更改）

- SCC牆H接近3m：4319.99952→3600 kgf/m²跳變已數值驗證，H=4m亦有跳變；保留並揭露。
- 一般側壓先min/max限制、再乘ρ/2403，沿用歷史順序，不宣稱現行規範校訂。
- 連續梁固定M=wL²/10、V=wL/2、δ=wL⁴/(128EI)，不是任意跨數通用解；自訂鋼型材仍用1.5V/A。
- 木柱≤、其他嚴格<沿用；柱牆2T與原1/2分攤配置適用性待確認。
- 接頭、斜撐、偏心、支架整體穩定及地基未檢核；未增加無根據容量。

发布前由根代理刷新遠端整合，再由父對話確認跨工具發布範圍。
